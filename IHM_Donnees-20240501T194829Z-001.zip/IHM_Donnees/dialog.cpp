#include "dialog.h"
#include "ui_dialog.h"
#include <QMessageBox>
//#include "creceptionxbee.h"
//#include "cconfig.h"


Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);

    //Crée Objets
    m_receveur = new CReceptionXBee;
    m_tempoSigfox = new QTimer(this);
    m_tempoXbee = new QTimer(this);
    m_bdd = new CDatabase;
    m_sigfox = new CEnvoiSigfox;
    //######################

    QList<QSerialPortInfo> listePorts;
    setFixedSize(width(), height());
    //Connects
    connect(m_tempoXbee,SIGNAL(timeout()) , m_receveur, SLOT(RecevoirData()));
    connect(m_receveur, SIGNAL(NouvelleTrame()), this, SLOT(recupData()));
    connect(m_tempoSigfox, SIGNAL(timeout()), this, SLOT(EnvoiData()));
    //Grisage du bouton
    ui->pushButtonFermer->setEnabled(false);
}

Dialog::~Dialog()
{
    delete ui;
    delete m_sigfox;
}


//Boutons Poussoirs

void Dialog::on_pushButtonOuvrir_clicked()
{

    if (m_receveur->Ouvrir()==false)
    {
        QMessageBox::critical(this,"Erreur","Erreur à l'ouverture du port !");
        return;
    }
    else
    {
        QMessageBox::information(this, "Réussite", "Connexion Réussie");

    }

    if (m_bdd->OuvrirAcces()==false)
    {
        QMessageBox::critical(this,"Erreur !", "Connexion à la base de données impossible !");
         m_receveur->Fermer();
        return;

    }
    else
    {
        QMessageBox::information(this,"Réussite !", "Connexion réussie à la base de données !");

    }
    if(m_sigfox->Ouvrir()==false)
    {
        QMessageBox::critical(this,"Erreur !", "Connexion au Sigfox Impossible !");
        m_bdd->FermerAcces();
        m_receveur->Fermer();
        return;

    }
    else
    {
        QMessageBox::information(this,"Réussite !", "Connexion au sigfox Réussi  !");
        ui->pushButtonFermer->setEnabled(true);
        ui->pushButtonOuvrir->setEnabled(false);
    }
     m_tempoXbee->start(m_config.get_valeur("TimerRecup", "1", "ConfTimer").toUInt()*1000);
     m_tempoSigfox->start(m_config.get_valeur("TimerSigfox", "840","ConfTimer").toUInt()*1000);
     connect(m_tempoXbee,SIGNAL(timeout()) , m_receveur, SLOT(RecevoirData()));
     connect(m_receveur, SIGNAL(NouvelleTrame()), this, SLOT(recupData()));
     connect(m_tempoSigfox, SIGNAL(timeout()), this, SLOT(EnvoiData()));
}





void Dialog::on_pushButtonFermer_clicked()
{
    m_tempoXbee->stop();
    m_receveur->Fermer();
    m_sigfox->Fermer();
    m_tempoSigfox->stop();
    disconnect(m_tempoXbee,SIGNAL(timeout()) , m_receveur, SLOT(RecevoirData()));
    disconnect(m_receveur, SIGNAL(NouvelleTrame()), this, SLOT(recupData()));
    disconnect(m_tempoSigfox, SIGNAL(timeout()), this, SLOT(EnvoiData()));
    ui->labelTrame->clear();
    ui->pushButtonFermer->setEnabled(false);
    ui->pushButtonOuvrir->setEnabled(true);
}


void Dialog::on_pushButtonCreate_clicked()
{
    m_config.CreateFichierConf();
}


// Fin Push Buttons


void Dialog::recupData()
{
    m_bdd->Inserer(m_receveur->get_temperature().toFloat(), m_receveur->get_humidite().toFloat(), m_receveur->get_xbee().toInt(), m_receveur->get_serre().toInt());
    ui->labelTrame->setText(m_receveur->get_trameFinal());
}

void Dialog::EnvoiData()
{
    m_sigfox->setTemperature(m_receveur->get_temperature().toFloat());
    m_sigfox->setHumidite(m_receveur->get_humidite().toFloat());
    m_sigfox->setNumSerre(m_receveur->get_serre().toInt());
    m_sigfox->setNumCapteur(m_receveur->get_xbee().toInt());
    m_sigfox->Envoi();
    ui->labelTrameSig->setText(m_sigfox->getTrame());
}

