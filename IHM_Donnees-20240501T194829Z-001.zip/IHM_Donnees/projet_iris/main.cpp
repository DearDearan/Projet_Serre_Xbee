                /* Auteur : N.PICARD
 * Date : 16/11/23
 * Titre : TP Bdd avec Qt
 */

#include <QCoreApplication>
#include <QtSql/QSqlDatabase>   //Utilisé pour utilisation d'une variable QSqlDatabase
#include <QtSql/QSqlQuery>  //Utilisé pour utilisation d'une variable QSqlQuery
#include <QtSql/QSqlRecord> //Utilisé pour utilisation d'une variable QSqlRecord
#include <QVariant> //Utilisé pour utilisation d'une variable QVariant
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    system("color F0");
    cout << endl << " ------------------ " << endl ;
    cout << endl << " Bdd avec Qt (1/2) " << endl ;
    cout << endl << " Test Qt-SQL" << endl ;

    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");  //Ajout d'une BBD
    db.setDatabaseName("projets_iris");   //Nom de la BDD
    db.setConnectOptions("");   //Option de connection (aucune dans notre cas)
    db.setHostName("localhost");    //adresse du la BDD (sur notre machine)
    db.setUserName("root"); //nom du compte de connexion à la BDD
    db.setPassword(""); //Mot de passe du compte de la BDD
    db.setPort(3306);   //Port de la BDD

    bool OK = db.open();
    cout << " Connexion \205 la BdD : "<< (OK ?" Oui":"Non")<< endl;
    if (!OK) return 1;

    //--------------------------------------------------------------------------------------------------------
        QSqlQuery requete1;//création d'une variables nomme requete 1 de type QSqlquerry
        requete1.clear();//
        OK = requete1.exec("SELECT Intitule FROM projets WHERE Annee = 2008");
        wcout<< L" Requ\210te 1 SELECT OK : " << (OK ?" Oui":" Non") <<endl<<endl;
        cout << endl << " ------------------ " << endl ;


        QString Intitule, Annee,Nom,Initiales;


        QSqlRecord rec1 = requete1.record();
        while (requete1.next())
        {
        Intitule = requete1.value("Intitule").toString();
        cout << " " << Intitule.toStdString() << " " << endl;
        }
        cout <<" ------------------ " << endl <<endl;
     //--------------------------------------------------------------------------------------------------------
        QSqlQuery requete2;//création d'une variables nomme requete 2 de type QSqlquerry
        requete2.clear();//
        OK = requete2.exec("SELECT Intitule,Annee FROM projets WHERE idProf = 1");
        wcout<< L" Requ\210te 2 SELECT OK : " << (OK ?" Oui":" Non") <<endl<<endl;
        cout << endl << " ------------------ " << endl ;
        QSqlRecord rec2 = requete2.record();
        while (requete2.next())
        {
        Intitule = requete2.value("Intitule").toString();
        Annee = requete2.value("Annee").toString();
        cout << " " << Intitule.toStdString() << " " << Annee.toStdString() << endl;
        }
        cout << " ------------------ " << endl<<endl;
    //--------------------------------------------------------------------------------------------------------
        QSqlQuery requete3;//création d'une variables nomme requete 2 de type QSqlquerry
        requete3.clear();//
        OK = requete3.exec("SELECT Nom FROM etudiants WHERE idProjet = 1");
        wcout<< L" Requ\210te 3 SELECT OK : " << (OK ?" Oui":" Non") <<endl<<endl;
        cout << endl << " ------------------ " << endl ;
        QSqlRecord rec3 = requete3.record();
        while (requete3.next())
        {
        Nom = requete3.value("Nom").toString();
        cout << " " << Nom.toStdString() << " "<<endl;
        }
        cout << " ------------------ " << endl<<endl;
    //--------------------------------------------------------------------------------------------------------
        QSqlQuery requete4;//création d'une variables nomme requete 2 de type QSqlquerry
        requete4.clear();//
        OK = requete4.exec("SELECT Intitule,Initiales FROM etudiants,projets,profs WHERE etudiants.idEtudiant=29 AND profs.idProf=projets.idProf AND projets.idProjet=etudiants.idProjet");
        wcout<< L" Requ\210te 4 SELECT OK : " << (OK ?" Oui":" Non") <<endl<<endl;
        cout << endl << " ------------------ " << endl ;
        QSqlRecord rec4 = requete4.record();
        while (requete4.next())
        {
        Intitule = requete4.value("Intitule").toString();
        Initiales = requete4.value("Initiales").toString();
        cout << " " << Intitule.toStdString() << " "<<Initiales.toStdString()<<endl;
        }
        cout << " ------------------ " << endl<<endl;
    //-------------------------------------------------------------------------------------------------------
    return 0; 			// fermeture avec appui sur la touche ENTREE
    //return a.exec();  // fermeture avec la croix de la fenêtre
}
