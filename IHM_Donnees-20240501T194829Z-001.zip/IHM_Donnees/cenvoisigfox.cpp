#include "cenvoisigfox.h"
//Constructeurs, destructeurs

CEnvoiSigfox::CEnvoiSigfox()
{
    m_sigfox.setPortName(config.get_valeur("Port", "", "ConfSigfox"));
    // Vitesse : 9600 bits
    m_sigfox.setBaudRate(config.get_valeur("BaudRate", "9600", "ConfSigfox").toUInt());
    // Nb de bits de données,
    m_sigfox.setDataBits(QSerialPort::Data8);
    // Nb de bits de stop
    m_sigfox.setStopBits(QSerialPort::OneStop);
    // Type de parité
    m_sigfox.setParity(QSerialPort::NoParity);
    // Contrôle de flux. Voilà.
    m_sigfox.setFlowControl(QSerialPort::NoFlowControl);
}

CEnvoiSigfox::~CEnvoiSigfox()
{
    m_sigfox.write("ATQ\r\n");
    m_sigfox.close();
}


// #############
bool CEnvoiSigfox::Ouvrir()
{
    m_sigfox.setPortName(config.get_valeur("Port", "", "ConfSigfox"));
    // Vitesse : 9600 bits
    m_sigfox.setBaudRate(config.get_valeur("BaudRate", "9600", "ConfSigfox").toUInt());
    // Nb de bits de données,
    m_sigfox.setDataBits(QSerialPort::Data8);
    // Nb de bits de stop
    m_sigfox.setStopBits(QSerialPort::OneStop);
    // Type de parité
    m_sigfox.setParity(QSerialPort::NoParity);
    // Contrôle de flux. Voilà.
    m_sigfox.setFlowControl(QSerialPort::NoFlowControl);
    if(m_sigfox.open(QIODevice::ReadWrite)==true)
    {
        // Retourne Vrai pour le QMessageBox de Dialog.
        m_sigfox.write("+++");
        m_sigfox.waitForBytesWritten(10000); // On attends que ça soit confirmer.
        emit EnvoiSigfox();
        return true;
    }
    else
    {
        return false;// Retourne Faux pour le QMessageBox de mainwindow.
    }
}


void CEnvoiSigfox::Fermer()
{
    m_sigfox.write("ATQ\r\n");
    m_sigfox.waitForBytesWritten(10000);
    m_sigfox.close();

}


// Signal

void CEnvoiSigfox::Envoi()
{

    QByteArray finalText;
    QString Texte = ("AT$SF="+shortIntToQBA(m_temperature).toHex()+ucharToQBA(m_humidite).toHex()+ucharToQBA(m_numSerre).toHex() +ucharToQBA(m_numCapteur).toHex()+",1\r\n");
    finalText.clear();
    finalText.insert(0, Texte);
    m_sigfox.write(finalText);
    trameSigfox = Texte;

    emit EnvoiSigfox();

}




//Convertisseurs

QByteArray CEnvoiSigfox::ucharToQBA(uchar anUchar)
{
    QByteArray qba(reinterpret_cast<const char *>(&anUchar), sizeof(uchar));
    return  qba;
}

QByteArray CEnvoiSigfox::shortIntToQBA(short aShortInt)
{
    QByteArray qba(reinterpret_cast<const char *>(&aShortInt), sizeof(short int));
    return  qba;
}


//Accesseurs
uchar CEnvoiSigfox::getHumidite()
{
    return m_humidite;
}

uchar CEnvoiSigfox::getNumSerre()
{
    return m_numSerre;
}

uchar CEnvoiSigfox::getNumCapteur()
{
    return m_numCapteur;
}

short int CEnvoiSigfox::getTemperature()
{
    return m_temperature;
}

QString CEnvoiSigfox::getTrame()
{
    return trameSigfox;
}
//Mutateurs

void CEnvoiSigfox::setHumidite(float hum)
{
    m_humidite = hum;
}

void CEnvoiSigfox::setNumSerre(int num)
{
    m_numSerre = num;
}

void CEnvoiSigfox::setNumCapteur(int num)
{
    m_numCapteur = num;
}

void CEnvoiSigfox::setTemperature(float temp)
{
    m_temperature = temp*10;
}
