#include "cconfig.h"

CConfig::CConfig()
{

}


void CConfig::CreateFichierConf()
{
    //Création fichier conf
    QSettings configuration("conf.ini", QSettings::IniFormat);

    // Groupe configuration Xbee
    configuration.beginGroup("ConfRadio");

    configuration.setValue("Port", "COM8");
    configuration.setValue("BaudRate", "9600");
//    configuration.setValue("DataBits","8"); // Utiliser les valeurs 5, 6 7 et 8 (type de data)
//    configuration.setValue("StopBits","1"); // 1 == OneStop, 2 == TwoStop, 3 == OneAndHalfStop
//    configuration.setValue("Parity","0");  // 0 == NoParity, 2 == EvenParity, 3 == OddParity, 4 == SpaceParity, 5 == MarkParity
//    configuration.setValue("FlowControl","0"); // 0==NoFlowControl, 1==HardwareControl, 2==SoftwareControl



    configuration.endGroup();
    // Groupe conf Sigfox

    configuration.beginGroup("ConfSigfox");

    configuration.setValue("Port","COM9");
    configuration.setValue("BaudRate", "19200");

    configuration.endGroup();

    //Groupe conf Timer

    configuration.beginGroup("ConfTimer");
    configuration.setValue("TimerRecup", "1");
    configuration.setValue("TimerSigfox", "840");
    configuration.endGroup();


    //Groupe conf Db
    configuration.beginGroup("Base_De_Donnees");

    configuration.setValue("Database", "gestion_de_serre");
    configuration.setValue("ConnectOptions","");
    configuration.setValue("Hostname", "localhost");
    configuration.setValue("Username", "root");
    configuration.setValue("Password", "");
    configuration.setValue("Port", 3306);

    configuration.endGroup(); // Pas très utile, mais il vaut mieux pour éviter tout bug.
}



QString CConfig::get_valeur(QString value, QString defaultValue, QString groupe)
{
    QSettings conf("conf.ini", QSettings::IniFormat);
    conf.beginGroup(groupe);
    QString valeur =  conf.value(value, defaultValue).toString(); // Récupère la valeur
    conf.endGroup();
    return  valeur;

}
