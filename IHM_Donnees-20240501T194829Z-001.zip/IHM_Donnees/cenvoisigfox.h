#ifndef CENVOISIGFOX_H
#define CENVOISIGFOX_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include <QDebug>

#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QByteArray>
#include <QDebug>

#include "cconfig.h"
#include "creceptionxbee.h"

class CEnvoiSigfox : public QObject
{
    Q_OBJECT
public:

    ~CEnvoiSigfox();
    CEnvoiSigfox();
    bool Ouvrir();
    void Fermer();
    QByteArray shortIntToQBA(short int aShortInt);
    QByteArray ucharToQBA(uchar anUchar);


    // Accesseurs
    short int getTemperature();
    uchar getHumidite();
    uchar getNumSerre();
    uchar getNumCapteur();
    QString getTrame();

    //Mutateurs
    void setTemperature(float temp);
    void setHumidite(float hum);
    void setNumSerre(int num);
    void setNumCapteur(int num);
private:
    QSerialPort m_sigfox;
    short int m_temperature;
    uchar m_humidite;
    uchar m_numSerre;
    uchar m_numCapteur;
    QString trameSigfox;

    CConfig config;
    CReceptionXBee m_recepteur;

   // QString ReponseTrame;  // Utilisé pour Debug

public slots:
    void Envoi();

signals:
    QString EnvoiSigfox();
};

#endif // CENVOISIGFOX_H
