#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //mettre ihm à jour
    ui->pbCo->setEnabled(true);
    ui->pbDeco->setEnabled(false);
    ui->comboEtu->setEnabled(false);
    ui->comboProf->setEnabled(false);
    ui->comboProj->setEnabled(false);
    ui->pbEtu_Proj->setEnabled(false);
    ui->pbProf_Proj->setEnabled(false);

    setFixedSize(650, 350);


}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pbCo_clicked()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");  //Ajout d'une BBD
    db.setDatabaseName("projets_iris");   //Nom de la BDD
    db.setConnectOptions("");   //Option de connection (aucune dans notre cas)
    db.setHostName("localhost");    //adresse du la BDD (sur notre machine)
    db.setUserName("root"); //nom du compte de connexion à la BDD
    db.setPassword(""); //Mot de passe du compte de la BDD
    db.setPort(3306);   //Port de la BDD

    bool OK = db.open();
    if (!OK) {QMessageBox::critical(this,"erreur","impossible de se connecter au serveur");}
    else {
        ui->pbCo->setEnabled(false);
        ui->pbDeco->setEnabled(true);
        ui->comboEtu->setEnabled(true);
        ui->comboProf->setEnabled(true);
        ui->comboProj->setEnabled(true);
        ui->pbEtu_Proj->setEnabled(true);
        ui->pbProf_Proj->setEnabled(true);}

    //---------------------------------------------------------------------------------------------------
    QSqlQuery requete1;//création d'une variables nomme requete 1 de type QSqlquerry
    requete1.clear();//
    requete1.exec("SELECT Nom FROM etudiants");

    while (requete1.next())
    {
        ui->comboEtu->addItem(requete1.value(0).toString());
    }
    //---------------------------------------------------------------------------------------------------
    QSqlQuery requete2;//création d'une variables nomme requete 1 de type QSqlquerry
    requete2.clear();//
    requete2.exec("SELECT Intitule FROM projets");

    while (requete2.next())
    {
        ui->comboProj->addItem(requete2.value(0).toString());
    }
    //---------------------------------------------------------------------------------------------------
    QSqlQuery requete3;//création d'une variables nomme requete 1 de type QSqlquerry
    requete3.clear();//
    requete3.exec("SELECT initiales FROM profs");

    while (requete3.next())
    {
        ui->comboProf->addItem(requete3.value(0).toString());
    }
    //---------------------------------------------------------------------------------------------------
}

void MainWindow::on_pbDeco_clicked()
{


    //mettre ihm à jour
    ui->pbCo->setEnabled(true);
    ui->pbDeco->setEnabled(false);
    ui->comboEtu->setEnabled(false);
    ui->comboProf->setEnabled(false);
    ui->comboProj->setEnabled(false);
    ui->pbEtu_Proj->setEnabled(false);
    ui->pbProf_Proj->setEnabled(false);
    ui->comboEtu->clear();
    ui->comboProj->clear();
    ui->comboProf->clear();
}

void MainWindow::on_pbEtu_Proj_clicked()
{
    QSqlQuery requete4;//création d'une variables nomme requete 1 de type QSqlquerry

    QString nom = ui->comboEtu->currentText();
    QString intitule = ui->comboProj->currentText();
    requete4.exec("SELECT projets.idProjet FROM projets WHERE projets.Intitule = '"+intitule+"';");
    QString idProjets;

    while (requete4.next())
    {
        idProjets = requete4.value(0).toString();
    }

    requete4.exec("UPDATE etudiants SET idProjet = '"+idProjets+"' WHERE Nom = '"+nom+"';"); //affiche tout

    QMessageBox::information(this,"Information","La base de données à été modifiée");
}

void MainWindow::on_pbProf_Proj_clicked()
{
    QSqlQuery requete5;//création d'une variables nomme requete 1 de type QSqlquerry

    QString nomP = ui->comboProf->currentText();
    QString intitule = ui->comboProj->currentText();
    requete5.exec("SELECT profs.idProf FROM profs WHERE profs.Initiales = '"+nomP+"';");
    QString idProfs;

    while (requete5.next())
    {
        idProfs = requete5.value(0).toString();
    }

    requete5.exec("UPDATE projets SET idProf = '"+idProfs+"' WHERE Intitule = '"+intitule+"';"); //affiche tout

    QMessageBox::information(this,"Information","La base de données à été modifiée");
}
