#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMessageBox>
#include <QCoreApplication>
#include <QtSql/QSqlDatabase>   //Utilisé pour utilisation d'une variable QSqlDatabase
#include <QtSql/QSqlQuery>  //Utilisé pour utilisation d'une variable QSqlQuery
#include <QtSql/QSqlRecord> //Utilisé pour utilisation d'une variable QSqlRecord
#include <QVariant> //Utilisé pour utilisation d'une variable QVariant

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pbCo_clicked();

    void on_pbDeco_clicked();

    void on_pbEtu_Proj_clicked();

    void on_pbProf_Proj_clicked();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
