#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>

#include <QTimer>
#include <QTime>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QByteArray>
#include <QSettings>
#include <QObject>

#include "cenvoisigfox.h"
#include "cconfig.h"
#include "creceptionxbee.h"
#include "cdatabase.h"

QT_BEGIN_NAMESPACE
namespace Ui { class Dialog; }
QT_END_NAMESPACE

class Dialog : public QDialog
{
    Q_OBJECT

public:
    Dialog(QWidget *parent = nullptr);
    ~Dialog();

private slots:
    void on_pushButtonOuvrir_clicked();
    void on_pushButtonFermer_clicked();
    void on_pushButtonCreate_clicked();



    void recupData();
    void EnvoiData();

private:
    Ui::Dialog *ui;

    // m_ pour membres de la classe

    QTimer *m_tempoSigfox, *m_tempoXbee;
    float m_temperatureFinal;
    float m_humiditeFinal;
    char m_checkEnvoi;

    //Classes persos
    CReceptionXBee* m_receveur;
    CConfig m_config;
    CDatabase *m_bdd;
    CEnvoiSigfox* m_sigfox;

signals:
    void EnvoiSig();
};
#endif // DIALOG_H
