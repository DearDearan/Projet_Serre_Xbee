#ifndef CRECEPTIONXBEE_H
#define CRECEPTIONXBEE_H

#include <QObject>
#include <QWidget>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QByteArray>

#include "cconfig.h"

class CReceptionXBee : public QObject
{

    Q_OBJECT
public:
    CReceptionXBee();
    //void RafraichirCOM();

    bool Ouvrir();
    void Fermer();
    void ClearTrame();


    //Accesseurs
    QString get_temperature();
    QString get_humidite();
    QString get_serre();
    QString get_xbee();
    QString get_trameFinal();



public slots:
    void RecevoirData();


private:
     QByteArray m_dataRecu;
     QString m_temperature, m_serre, m_xbeeTarget, m_humidite, m_tramefinal;
     QSerialPort m_Xbee; // Ports utilisés
        CConfig config;

signals:
     void NouvelleTrame();


};
#endif // CRECEPTIONXBEE_H
