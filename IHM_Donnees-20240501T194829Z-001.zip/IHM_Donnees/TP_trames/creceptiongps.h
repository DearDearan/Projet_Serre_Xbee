/*
* ???
* ???
*/

#ifndef CRECEPTIONGPS_H
#define CRECEPTIONGPS_H

#include <QObject>
#include <QtSerialPort/QSerialPort>
#include <QTime>
#include <cmath> // For the FLOOR

// Classe d'extraction des informations d'une trame NMEA d'un GPS
class CReceptionGPS : public QObject
{
  Q_OBJECT
private:
  // Vrai si le port série de réception des trames NMEA est bien ouvert et opérat
  bool m_port_ouvert;

  // Altitude en mètre
  double m_altitude;

  // Latitude en degrés décimaux
  double m_latitude;

  // Longitude en degrés décimaux
  double m_longitude;

  // Nombre de satellites utilisés par le GPS
  int m_nbesat;

  // Heure UTC de la dernière trame NMEA reçue
  QTime m_timereception;

  // Stockage d'une trame NMEA reçue pour traitement
  QByteArray m_tramerecue;

  // Objet QSerialPort utilisé pour l'accès au port série du GPS
  QSerialPort PortSerie;

public:
  // Constructeur
  //Ouvre et configure le port série du GPS passé en paramètre
  //Met à jour l'attribut m_port_ouvert
  explicit CReceptionGPS (QString Port);

  // Destructeur
  //Ferme le port série
  //Met à jour l'attribut m_port_ouvert
  ~CReceptionGPS ();

  // Retourne l'état du port série du GPS
  //Vrai si le port est ouvert et opérationnel, faux sinon
  bool get_port_ouvert();
  double get_altitude();
  double get_latitude();
  double get_longitude();
  // Retourne le nombre de satellites utilisés par le GPS
  int get_nbesat();
  // Retourne l'heure UTC de la dernière trame NMEA reçue au format hh:mm:ss
  QTime get_timereception();

private:
  // Vérifie la somme de contrôle de la trame dans l'attibut m_tramerecue
  // Retourne vrai si la somme de contrôle est correcte, faux sinon
 // bool VerifChecksum();

private slots:
  // Slot de traitement des trames NMEA envoyées par le GPS
  // Ce slot sera connecté au signal readyRead() du port série du GPS
  void TraiterTrames();

signals:
  // Signal émis quand de nouvelles informations sont disponibles
  // Ce signal sera connecté au slot AfficherPositions() de la fenêtre d'affichage
  void NouvellesPositions();
};

#endif // CRECEPTIONGPS_H
