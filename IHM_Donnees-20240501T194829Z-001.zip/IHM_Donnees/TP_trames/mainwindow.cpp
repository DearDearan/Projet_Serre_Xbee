#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "creceptiongps.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    setFixedSize(width(), height());
    ui->setupUi(this);
    gps = new CReceptionGPS("COM3");
    connect(gps,SIGNAL(NouvellesPositions()), this, SLOT(AfficherPosition()));
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::AfficherPosition()
{
    ui->labelLong->setNum(gps->get_longitude());
    ui->labelLat->setNum(gps->get_latitude());
    ui->labelAlt->setNum(gps->get_altitude());
    ui->labelSat->setNum(gps->get_nbesat());
    ui->labelHeure->setText(gps->get_timereception().toString());

    //Récupération dms

    double latitude = gps->get_latitude();
    QString DMS_latdegres = QString::number(floor(latitude));

    double lat_minute = (latitude-floor(latitude))*60;
    QString DMS_latminute = QString::number(lat_minute,'f',0);

    double lat_seconde = (lat_minute-floor(lat_minute))*60;
    QString DMS_latseconde = QString::number(lat_seconde,'f',2);

    //Affichage

    ui->labelDMSDeg->setText(DMS_latdegres);
    ui->labelDMSMin->setText(DMS_latminute);
    ui->labelDMSSec->setText(DMS_latseconde);

}
