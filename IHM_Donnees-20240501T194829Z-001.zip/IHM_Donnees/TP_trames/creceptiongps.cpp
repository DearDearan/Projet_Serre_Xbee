#include "creceptiongps.h"

CReceptionGPS::CReceptionGPS(QString Port)
{
    PortSerie.setPortName(Port);
    PortSerie.setBaudRate(4800);
    //Nb de bits de stop : 1
    PortSerie.setStopBits(QSerialPort::OneStop);

    //Type de parité : paire
    PortSerie.setParity(QSerialPort::EvenParity);

    //Contrôle du flux : aucun
    PortSerie.setFlowControl(QSerialPort::NoFlowControl);

    // Ouverture du port
    m_port_ouvert = PortSerie.open(QIODevice::ReadOnly);

    if (m_port_ouvert==true)
    {
        connect(&PortSerie,SIGNAL(readyRead()),this,SLOT(TraiterTrames()));
    }

}

// Destructeur
//Ferme le port série
//Met à jour l'attribut m_port_ouvert
CReceptionGPS::~CReceptionGPS (){
    PortSerie.close();
    disconnect(&PortSerie,SIGNAL(readyRead()),this,SLOT(TraiterTrames()));
    m_port_ouvert = false;
}

// Retourne l'état du port série du GPS
//Vrai si le port est ouvert et opérationnel, faux sinon
bool CReceptionGPS::get_port_ouvert()
{
    return m_port_ouvert;
}

// Retourne l'altitude en mètres
double CReceptionGPS::get_altitude()
{
    return  m_altitude;
}

// Retourne la latitude en degrès décimaux
double CReceptionGPS::get_latitude()
{
    return m_latitude;
}

// Retourne la longitude en degrès décimaux
double CReceptionGPS::get_longitude()
{
    return m_longitude;
}
// Retourne le nombre de satellites utilisés par le GPS
int CReceptionGPS::get_nbesat()
{
    return m_nbesat;
}
// Retourne l'heure UTC de la dernière trame NMEA reçue au format hh:mm:ss
QTime CReceptionGPS::get_timereception()
{
    return m_timereception;
}

// Vérifie la somme de contrôle de la trame dans l'attibut m_tramerecue
// Retourne vrai si la somme de contrôle est correcte, faux sinon

//bool CReceptionGPS::VerifChecksum (){
//}

// Slot de traitement des trames NMEA envoyées par le GPS
// Ce slot sera connecté au signal readyRead() du port série du GPS
void CReceptionGPS::TraiterTrames()
{
    //lecture d'une trame (1 ligne de données reçu sur le port série
    m_tramerecue = PortSerie.readLine();
    //    QByteArray DebutTrame = m_tramerecue.read(6);
    //    if (m_tramerecue=="$GPGGA") //QByteARRAY
    //    {

    //    }
    if (m_tramerecue.startsWith("$GPGGA"))
    {
        //Traitement de la trame
        //Découpage de la trame par rapport au séparation utilisé (,)
        QList <QByteArray> tramedecoupe;
        tramedecoupe = m_tramerecue.split(',');

        // Déclarations variables latitudes
        double latitude=0,latitude1=0,latitude2=0;

        latitude = tramedecoupe[2].toDouble();
        //Extraction degrés
        latitude1 = floor(latitude/100);
        latitude2 = latitude-(latitude1*100);
        m_latitude = latitude1 + (latitude2/60);

        // Déclarations variables longitudes
        double longitude,longitude1, longitude2;
        longitude = tramedecoupe[4].toDouble();
        //Extraction degrés
        longitude1 = floor(longitude/100);
        longitude2 = longitude-(longitude1*100);
        m_longitude = longitude1 + (longitude2/60);

        //récupération de l'altitude

        m_altitude = tramedecoupe[9].toDouble();


        // Récupération des satellites

        m_nbesat = tramedecoupe[7].toInt();

        //Récupération de l'heure

        QString time = tramedecoupe[1];
        m_timereception = QTime::fromString(time, "hhmmss.zzz");

        //Emission de fin de traitement

        emit NouvellesPositions();
    }
}
