#ifndef CCONFIG_H
#define CCONFIG_H

#include <QSettings>

class CConfig : public QObject
{
public:
    CConfig();
    void CreateFichierConf();
    QString get_valeur(QString value, QString defaultValue, QString groupe);

};

#endif // CCONFIG_H
