#include "creceptionxbee.h"


CReceptionXBee::CReceptionXBee()
{
    m_Xbee.setPortName(config.get_valeur("Port", "", "ConfRadio"));
    // Vitesse : 9600 bits
    m_Xbee.setBaudRate(config.get_valeur("BaudRate", "9600", "ConfRadio").toUInt());
    // Nb de bits de données,
    m_Xbee.setDataBits(QSerialPort::Data8);
    // Nb de bits de stop
    m_Xbee.setStopBits(QSerialPort::OneStop);
    // Type de parité
    m_Xbee.setParity(QSerialPort::NoParity);
    // Contrôle de flux. Voilà.
    m_Xbee.setFlowControl(QSerialPort::NoFlowControl);
}

void CReceptionXBee::RecevoirData()
{
    QList<QByteArray> decoupeTrame;
    if(m_Xbee.canReadLine()==true)
    {
        m_dataRecu = m_Xbee.readLine();
        if(m_dataRecu.startsWith("$X"))
        {
            decoupeTrame = m_dataRecu.split(',');
        }
        //    QString trame0 = decoupeTrame[0];
        m_serre = decoupeTrame[1];
        m_xbeeTarget = decoupeTrame[2];
        m_temperature = decoupeTrame[3];
        m_humidite = decoupeTrame[4];
        //    QString trame5 = decoupeTrame[5]

        m_tramefinal = decoupeTrame[0];
        for(unsigned int i = 1; i<6; i++)
        {
            m_tramefinal = m_tramefinal + ", "  + decoupeTrame[i];
        }

        emit NouvelleTrame();
    }

}

bool CReceptionXBee::Ouvrir()
{
    m_Xbee.setPortName(config.get_valeur("Port", "", "ConfRadio"));
    // Vitesse : 9600 bits
    m_Xbee.setBaudRate(config.get_valeur("BaudRate", "9600", "ConfRadio").toUInt());
    // Nb de bits de données,
    m_Xbee.setDataBits(QSerialPort::Data8);
    // Nb de bits de stop
    m_Xbee.setStopBits(QSerialPort::OneStop);
    // Type de parité
    m_Xbee.setParity(QSerialPort::NoParity);
    // Contrôle de flux
    m_Xbee.setFlowControl(QSerialPort::NoFlowControl);
    // ouvrir le port série et vérifier la réussite
    if(m_Xbee.open(QIODevice::ReadOnly)==true)
    {

        return true; // Retourne Vrai pour le QMessageBox de mainwindow.
        connect(&m_Xbee,SIGNAL(readyRead()),this,SLOT(RecevoirData()));
    }
    else
    {
        return false;// Retourne Faux pour le QMessageBox de mainwindow.
    }

}

void CReceptionXBee::Fermer()
{
    m_dataRecu.clear();
    m_Xbee.close();

}


// Getters


QString CReceptionXBee::get_humidite()
{
    return m_humidite;
}

QString CReceptionXBee::get_xbee()
{
    return m_xbeeTarget;
}

QString CReceptionXBee::get_temperature()
{
    return m_temperature;
}

QString CReceptionXBee::get_serre()
{
    return m_serre;
}

QString CReceptionXBee::get_trameFinal()
{
    return m_tramefinal;
}

// Clear de trame final

void CReceptionXBee::ClearTrame()
{
    m_tramefinal.clear();
}
