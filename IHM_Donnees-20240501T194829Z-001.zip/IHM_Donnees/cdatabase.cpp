#include "cdatabase.h"

CDatabase::CDatabase()
{
    m_bdd = QSqlDatabase::addDatabase("QMYSQL");  //Ajout d'une BBD
    m_bdd.setDatabaseName(conf.get_valeur("Database", "error", "Base_De_Donnees"));   //Nom de la BDD
    m_bdd.setConnectOptions(conf.get_valeur("ConnectOptions", "", "Base_De_Donnees"));   //Option de connection (aucune dans notre cas)
    m_bdd.setHostName(conf.get_valeur("Hostname","%","Base_De_Donnees"));    //adresse du la BDD (sur notre machine)
    m_bdd.setUserName(conf.get_valeur("Username", "root", "Base_De_Donnees")); //nom du compte de connexion à la BDD
    m_bdd.setPassword(conf.get_valeur("Password", "", "Base_De_Donnees")); //Mot de passe du compte de la BDD
    m_bdd.setPort(conf.get_valeur("Port", "", "Base_De_Donnees").toInt());   //Port de la BDD

    m_request = new QSqlQuery(m_bdd);
}


bool CDatabase::OuvrirAcces() //Ouvre la BDD
{
    return m_bdd.open();
}

void CDatabase::FermerAcces() //Ferme la BDD
{
    m_bdd.close();
}




void CDatabase::Inserer(float temperature, float humidite, unsigned int idCapteur, unsigned int id_serre) // Insère les données, l'ID est A_I donc raf de ça
{

    m_request->clear();
    QString temp = temp.number(temperature);
    QString hum = hum.number(humidite);
    QString idCap = idCap.number(idCapteur);
    QString idSerre = idSerre.number(id_serre);
    m_request->exec("INSERT INTO data_mesures (temperature, humidite, idCapteur, id_serre, horodatage) VALUES ('"+temp+"','"+hum+"', '"+idCap+"','"+idSerre+"', NOW());");
}
