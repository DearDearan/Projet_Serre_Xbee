#ifndef CDATABASE_H
#define CDATABASE_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include <QtSql/QSqlDatabase>   //Utilisé pour utilisation d'une variable QSqlDatabase
#include <QtSql/QSqlQuery>  //Utilisé pour utilisation d'une variable QSqlQuery
#include <QtSql/QSqlRecord> //Utilisé pour utilisation d'une variable QSqlRecord
#include <QVariant> //Utilisé pour utilisation d'une variable QVariant

#include "cconfig.h"

class CDatabase : public QObject

{
    Q_OBJECT
public:
    CDatabase();
    bool OuvrirAcces();
    void FermerAcces();
    void Inserer(float temperature, float humidite, unsigned int idCapteur, unsigned int id_serre);
private:
    QSqlDatabase m_bdd;
    QSqlQuery* m_request;
    CConfig conf;

};

#endif // CDATABASE_H
